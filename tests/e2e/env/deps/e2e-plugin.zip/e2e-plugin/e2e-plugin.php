<?php
/**
 * Plugin Name: WooCommerce e2e plugin
 * Plugin URI: https://woocommerce.github.io/
 * Description: A very basic plugin to test WooCommerce e2e flows.
 * Version: 1.0
 * Author: WooCommerce
 * Author URI: https://woocommerce.github.io/
 */
